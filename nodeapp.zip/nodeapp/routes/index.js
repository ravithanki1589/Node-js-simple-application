var express = require('express')
, router = express.Router();
var siteController     = require('../controllers/site');
router.get('/',siteController.index);
module.exports = router
