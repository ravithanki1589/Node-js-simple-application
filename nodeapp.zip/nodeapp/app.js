var express = require('express')
  , routes = require('./routes');
const http = require('http');
const hostname = '127.0.0.1';
const port = 3001;
var app = express();
var engine = require('ejs-locals');
app.set('port', port);
app.set('views', __dirname + '/views');
app.engine('ejs', engine);
app.set('view engine', 'ejs');
const server = http.createServer((req, res) => {
  res.statusCode = 200;
  res.setHeader('Content-Type', 'text/plain');
  res.end('Hello World');
});

app.use(routes)

app.listen(port, function () {
  console.log('Example app listening on port '+port);
});