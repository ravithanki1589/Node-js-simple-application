var express = require('express')
    , router = express.Router();
router.index = function (req, res) {
	
	res.render('index', {title: 'welcome'})
};

module.exports = router
